import{_ as e,f as t,g as n,h as r,l as i,p as a,r as o,u as s,v as c,y as l}from"./store-Dh4ILraf.js";import{d as u,l as d,n as f,r as p,u as m}from"./index-DddqyVLI.js";var h=p(`copy`,[[`rect`,{width:`14`,height:`14`,x:`8`,y:`8`,rx:`2`,ry:`2`,key:`17jyea`}],[`path`,{d:`M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2`,key:`zix9uf`}]]),g=p(`download`,[[`path`,{d:`M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4`,key:`ih7n3h`}],[`polyline`,{points:`7 10 12 15 17 10`,key:`2ggqvy`}],[`line`,{x1:`12`,x2:`12`,y1:`15`,y2:`3`,key:`1vk2je`}]]),_=p(`printer`,[[`path`,{d:`M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2`,key:`143wyd`}],[`path`,{d:`M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6`,key:`1itne7`}],[`rect`,{x:`6`,y:`14`,width:`12`,height:`8`,rx:`1`,key:`1ue0tg`}]]),v=p(`share-2`,[[`circle`,{cx:`18`,cy:`5`,r:`3`,key:`gq8acd`}],[`circle`,{cx:`6`,cy:`12`,r:`3`,key:`w7nqdw`}],[`circle`,{cx:`18`,cy:`19`,r:`3`,key:`1xt0gg`}],[`line`,{x1:`8.59`,x2:`15.42`,y1:`13.51`,y2:`17.49`,key:`47mynk`}],[`line`,{x1:`15.41`,x2:`8.59`,y1:`6.51`,y2:`10.49`,key:`1n3mei`}]]),y=u(m());function b(e){let t=e==null?``:String(e);return/[;"\n]/.test(t)?`"${t.replace(/"/g,`""`)}"`:t}function x(t){return`\uFEFF${[[`Data`,`Início`,`Término`,`Duração`,`Obra`,`Rua`,`Máquina`,`Atividade`,`Estaca`,`PV`,`Qtd`,`Observações`,`Descrição`],...t.map(t=>{t.end??c();let i=t.end?n(e(t.start,t.end)):`em andamento`;return[r(t.date),t.start,t.end??``,i,t.workName,t.streetName,t.equipmentName,t.activityName,t.estaca,t.pv,t.quantity??``,t.notes,t.description].map(b)})].map(e=>e.join(`;`)).join(`
`)}`}function S(e,t,n){let r=new Blob([t],{type:n}),i=URL.createObjectURL(r),a=document.createElement(`a`);a.href=i,a.download=e,a.click(),URL.revokeObjectURL(i)}function C(e,t){let n=[...t].sort((e,t)=>e.start.localeCompare(t.start)),i=`${r(e)}`,a=n[0]?.workName??``,o=[`${i}${a?` — ${a}`:``}`,``];if(n.length===0)return o.push(`Nenhum apontamento neste dia.`),o.join(`
`);for(let e of n){let t=e.end?`${e.start}–${e.end}`:`${e.start}–…`;o.push(`${t}  ${e.equipmentName}`);let n=[e.activityName,e.streetName,e.estaca&&`Estaca ${e.estaca}`,e.pv].filter(Boolean);o.push(n.join(` — `)),e.notes&&o.push(`Obs: ${e.notes}`),o.push(``)}return o.join(`
`).trim()+`
`}function w(e,t){let n=window.open(``,`_blank`);n&&(n.document.write(`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"/>
<title>${e}</title>
<style>
  body { font-family: "Source Sans 3", "Segoe UI", sans-serif; color: #1c1814; padding: 24px; }
  h1 { font-size: 20px; margin: 0 0 4px; }
  p.meta { color: #6b6358; margin: 0 0 20px; font-size: 13px; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; }
  th, td { border: 1px solid #ddd4c6; padding: 6px 8px; text-align: left; vertical-align: top; }
  th { background: #efe8db; font-weight: 600; }
  .desc { color: #6b6358; font-size: 11px; }
  @page { margin: 16mm; }
</style></head><body>${t}</body></html>`),n.document.close(),n.focus(),n.print())}var T=d();function E(){let{apontamentos:c}=o(),[u,d]=(0,y.useState)(l()),[p,m]=(0,y.useState)(l()),b=(0,y.useMemo)(()=>[...c].filter(e=>e.date>=u&&e.date<=p).sort((e,t)=>e.date===t.date?e.start.localeCompare(t.start):e.date.localeCompare(t.date)),[c,u,p]),E=(0,y.useMemo)(()=>{let t=new Map;for(let n of b){let r=t.get(n.equipmentId)??{name:n.equipmentName,n:0,mins:0};r.n+=1,n.end&&(r.mins+=e(n.start,n.end)),t.set(n.equipmentId,r)}return[...t.values()].sort((e,t)=>t.mins-e.mins)},[b]),O=(0,y.useMemo)(()=>u===p?C(u,b):[...new Set(b.map(e=>e.date))].map(e=>C(e,b.filter(t=>t.date===e))).join(`

`),[u,p,b]);async function k(){await navigator.clipboard.writeText(O),f.success(`Diário copiado`)}async function A(){if(navigator.share){await navigator.share({title:`Diário de apontamento`,text:O});return}await k()}function j(){S(`apontamento_${u}_${p}.csv`,x(b),`text/csv;charset=utf-8`),f.success(`Planilha baixada (abre no Excel)`)}function M(){w(`Relatório de apontamento`,`
      <h1>Relatório de apontamento</h1>
      <p class="meta">${r(u)} a ${r(p)} · ${b.length} registros</p>
      <table>
        <thead><tr>
          <th>Horário</th><th>Máquina</th><th>Atividade</th><th>Rua</th><th>Estaca</th><th>PV</th>
        </tr></thead>
        <tbody>
          ${b.map(e=>`<tr>
            <td>${r(e.date)}<br/>${e.start}${e.end?`–${e.end}`:``}</td>
            <td>${D(e.equipmentName)}</td>
            <td>${D(e.activityName)}${e.notes?`<div class="desc">${D(e.notes)}</div>`:``}</td>
            <td>${D(e.streetName)}</td>
            <td>${D(e.estaca)}</td>
            <td>${D(e.pv)}</td>
          </tr>`).join(``)}
        </tbody>
      </table>`)}return(0,T.jsxs)(a,{children:[(0,T.jsxs)(`header`,{className:`px-4 pb-3 pt-[max(16px,env(safe-area-inset-top))]`,children:[(0,T.jsx)(`h1`,{className:`font-display text-2xl font-semibold`,children:`Relatório`}),(0,T.jsx)(`p`,{className:`text-sm text-muted`,children:`Resumo, Excel e PDF do período.`})]}),(0,T.jsxs)(`main`,{className:`flex flex-col gap-4 px-4 pb-6`,children:[(0,T.jsxs)(`div`,{className:`grid grid-cols-2 gap-3`,children:[(0,T.jsxs)(`div`,{children:[(0,T.jsx)(s,{children:`De`}),(0,T.jsx)(i,{type:`date`,value:u,onChange:e=>d(e.target.value)})]}),(0,T.jsxs)(`div`,{children:[(0,T.jsx)(s,{children:`Até`}),(0,T.jsx)(i,{type:`date`,value:p,onChange:e=>m(e.target.value)})]})]}),(0,T.jsxs)(`section`,{className:`rounded-xl border border-border bg-surface p-4 shadow-card`,children:[(0,T.jsxs)(`p`,{className:`text-sm text-muted`,children:[b.length,` apontamentos no período`]}),(0,T.jsxs)(`ul`,{className:`mt-3 flex flex-col gap-2`,children:[E.map(e=>(0,T.jsxs)(`li`,{className:`flex justify-between gap-3 text-sm`,children:[(0,T.jsx)(`span`,{className:`min-w-0 truncate font-medium`,children:e.name}),(0,T.jsxs)(`span`,{className:`shrink-0 tabular-nums text-muted`,children:[e.n,` · `,n(e.mins)]})]},e.name)),E.length===0?(0,T.jsx)(`li`,{className:`text-sm text-muted`,children:`Sem dados neste intervalo.`}):null]})]}),(0,T.jsxs)(`div`,{className:`grid grid-cols-2 gap-2`,children:[(0,T.jsxs)(t,{variant:`outline`,onClick:j,children:[(0,T.jsx)(g,{className:`size-4`}),`Excel`]}),(0,T.jsxs)(t,{variant:`outline`,onClick:M,children:[(0,T.jsx)(_,{className:`size-4`}),`PDF`]}),(0,T.jsxs)(t,{variant:`outline`,onClick:k,children:[(0,T.jsx)(h,{className:`size-4`}),`Copiar`]}),(0,T.jsxs)(t,{variant:`outline`,onClick:()=>void A(),children:[(0,T.jsx)(v,{className:`size-4`}),`Enviar`]})]}),(0,T.jsx)(`pre`,{className:`overflow-x-auto whitespace-pre-wrap rounded-xl border border-border bg-surface p-4 font-sans text-sm leading-relaxed text-fg`,children:O||`Nada para exportar.`})]})]})}function D(e){return e.replace(/[&<>]/g,e=>({"&":`&`,"<":`<`,">":`>`})[e]??e)}export{E as component};