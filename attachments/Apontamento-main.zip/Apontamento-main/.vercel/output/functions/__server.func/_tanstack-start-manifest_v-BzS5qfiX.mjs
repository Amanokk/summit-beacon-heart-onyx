//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BzS5qfiX.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/cadastros",
			"/historico",
			"/novo",
			"/relatorio"
		],
		preloads: ["/assets/index-DddqyVLI.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DddqyVLI.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Ca2ZTS3z.js",
			"/assets/store-Dh4ILraf.js",
			"/assets/hydrate-viqH32gY.js"
		]
	},
	"/cadastros": {
		filePath: "/workspace/src/routes/cadastros.tsx",
		children: void 0,
		preloads: [
			"/assets/cadastros-CdOYKLwS.js",
			"/assets/store-Dh4ILraf.js",
			"/assets/choice-DNoLvFvl.js"
		]
	},
	"/historico": {
		filePath: "/workspace/src/routes/historico.tsx",
		children: void 0,
		preloads: ["/assets/historico-CBDd1QOI.js", "/assets/store-Dh4ILraf.js"]
	},
	"/novo": {
		filePath: "/workspace/src/routes/novo.tsx",
		children: void 0,
		preloads: [
			"/assets/novo-CvLPpOvw.js",
			"/assets/store-Dh4ILraf.js",
			"/assets/choice-DNoLvFvl.js",
			"/assets/hydrate-viqH32gY.js"
		]
	},
	"/relatorio": {
		filePath: "/workspace/src/routes/relatorio.tsx",
		children: void 0,
		preloads: ["/assets/relatorio-DMB03L1a.js", "/assets/store-Dh4ILraf.js"]
	}
} });
//#endregion
export { tsrStartManifest };
