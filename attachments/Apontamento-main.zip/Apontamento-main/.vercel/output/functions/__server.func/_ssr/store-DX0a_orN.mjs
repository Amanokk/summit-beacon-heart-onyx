import { S as require_jsx_runtime, f as useRouterState, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Settings2, g as CalendarDays, l as Plus, m as ClipboardList, u as FileSpreadsheet } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-DX0a_orN.js
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function todayISO() {
	const d = /* @__PURE__ */ new Date();
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function nowHHMM() {
	const d = /* @__PURE__ */ new Date();
	return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}
function formatDateBR(iso) {
	const [y, m, d] = iso.split("-");
	if (!y || !m || !d) return iso;
	return `${d}/${m}/${y}`;
}
function formatEstaca(value) {
	const v = value.trim();
	if (!v) return "";
	if (/^e\s?/i.test(v) || /\+/.test(v)) return v.replace(/^e\s*/i, "E ").toUpperCase().replace(/^E /, "E ");
	if (/^\d+$/.test(v)) return `E ${v}`;
	return v;
}
function minutesBetween(start, end) {
	const [sh, sm] = start.split(":").map(Number);
	const [eh, em] = end.split(":").map(Number);
	if ([
		sh,
		sm,
		eh,
		em
	].some((n) => Number.isNaN(n))) return 0;
	return Math.max(0, eh * 60 + em - (sh * 60 + sm));
}
function formatDuration(mins) {
	if (mins <= 0) return "0 min";
	const h = Math.floor(mins / 60);
	const m = mins % 60;
	if (h === 0) return `${m} min`;
	if (m === 0) return `${h}h`;
	return `${h}h ${String(m).padStart(2, "0")}`;
}
function uid() {
	if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
	return `id_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}
var NAV = [
	{
		to: "/",
		label: "Hoje",
		icon: CalendarDays
	},
	{
		to: "/novo",
		label: "Novo",
		icon: Plus
	},
	{
		to: "/historico",
		label: "Histórico",
		icon: ClipboardList
	},
	{
		to: "/relatorio",
		label: "Relatório",
		icon: FileSpreadsheet
	},
	{
		to: "/cadastros",
		label: "Cadastros",
		icon: Settings2
	}
];
function AppShell({ children, hideNav }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh max-w-lg flex-col bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("flex min-h-0 flex-1 flex-col", hideNav ? "pb-0" : "pb-20"),
			children
		}), hideNav ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "no-print fixed inset-x-0 bottom-0 z-30 border-t border-border bg-surface/95 backdrop-blur-sm",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid max-w-lg grid-cols-5 px-1 pb-[env(safe-area-inset-bottom)] pt-1",
				children: NAV.map((item) => {
					const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
					const Icon = item.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.to,
						className: cn("flex min-h-12 flex-col items-center justify-center gap-0.5 rounded-md text-[11px] font-medium", active ? "text-primary" : "text-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-5",
							strokeWidth: active ? 2.4 : 1.8
						}), item.label]
					}, item.to);
				})
			})
		})]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-colors duration-150 disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg hover:bg-primary/90",
			secondary: "bg-surface-2 text-fg hover:bg-border",
			outline: "border border-border bg-surface text-fg hover:bg-surface-2",
			ghost: "text-fg hover:bg-surface-2",
			danger: "bg-danger text-primary-fg hover:bg-danger/90"
		},
		size: {
			default: "h-12 rounded-md px-4 text-base",
			sm: "h-9 rounded-sm px-3 text-sm",
			lg: "h-14 rounded-lg px-5 text-lg",
			icon: "size-12 rounded-md"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-12 w-full rounded-md border border-border bg-surface px-3 text-base text-fg placeholder:text-subtle", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("min-h-20 w-full rounded-md border border-border bg-surface px-3 py-2 text-base text-fg placeholder:text-subtle", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("mb-1.5 block text-sm font-medium text-muted", className),
		...props
	});
}
/** Atividades extraídas dos diários G001 / APONTAMENTO das planilhas reais. */
var ACTIVITIES = [
	{
		id: "transp-equip-frente",
		name: "Transporte de equipamentos para frente de serviço",
		kind: "deslocamento"
	},
	{
		id: "preparo-calcada",
		name: "Preparo de calçada",
		kind: "servico"
	},
	{
		id: "exec-caixa-ralo",
		name: "Execução de caixa ralo",
		kind: "servico"
	},
	{
		id: "exec-ramal",
		name: "Execução de ramal",
		kind: "servico"
	},
	{
		id: "icamento-caixa-ralo",
		name: "Içamento de caixa ralo",
		kind: "servico"
	},
	{
		id: "icamento-ramal",
		name: "Içamento de ramal",
		kind: "servico"
	},
	{
		id: "alteamento-tampa",
		name: "Alteamento de tampa",
		kind: "servico"
	},
	{
		id: "espalh-bica-base",
		name: "Espalhamento de bica para base",
		kind: "servico"
	},
	{
		id: "espalh-bica-subbase",
		name: "Espalhamento de bica para sub-base",
		kind: "servico"
	},
	{
		id: "espalh-mat-subbase",
		name: "Espalhamento de material para sub-base",
		kind: "servico"
	},
	{
		id: "carreg-cam-bica",
		name: "Carregamento de caminhão de bica",
		kind: "servico"
	},
	{
		id: "carreg-cam-mat",
		name: "Carregamento de caminhão de material",
		kind: "servico"
	},
	{
		id: "descarga-aneis",
		name: "Descarga de anéis de concreto",
		kind: "servico"
	},
	{
		id: "descarga-tubos",
		name: "Descarga de tubos",
		kind: "servico"
	},
	{
		id: "demolicao-calcada",
		name: "Demolição de calçada",
		kind: "servico"
	},
	{
		id: "demolicao-emborcadura",
		name: "Demolição de emborcadura",
		kind: "servico"
	},
	{
		id: "limpeza-material",
		name: "Limpeza de material",
		kind: "servico"
	},
	{
		id: "org-canteiro",
		name: "Organização de material no canteiro",
		kind: "servico"
	},
	{
		id: "org-desague",
		name: "Limpeza e organização no deságue",
		kind: "servico"
	},
	{
		id: "escavacao",
		name: "Escavação",
		kind: "servico"
	},
	{
		id: "abertura-vala",
		name: "Abertura de vala",
		kind: "servico"
	},
	{
		id: "reaterro",
		name: "Reaterro",
		kind: "servico"
	},
	{
		id: "reaterro-escada",
		name: "Reaterro de escada hidráulica",
		kind: "servico"
	},
	{
		id: "reparo-erosao",
		name: "Reparo de erosão",
		kind: "servico"
	},
	{
		id: "reparo-esgoto",
		name: "Reparo de esgoto de morador",
		kind: "servico"
	},
	{
		id: "reparo-caixa-ralo",
		name: "Reparo de caixa ralo",
		kind: "servico"
	},
	{
		id: "troca-solo-borrachudo",
		name: "Troca de solo borrachudo",
		kind: "servico"
	},
	{
		id: "exec-drenagem",
		name: "Execução de drenagem",
		kind: "servico"
	},
	{
		id: "regularizacao-via",
		name: "Regularização da via",
		kind: "servico"
	},
	{
		id: "nivelamento",
		name: "Nivelamento",
		kind: "servico"
	},
	{
		id: "carreg-mat-subbase",
		name: "Carregamento de material para sub-base",
		kind: "servico"
	},
	{
		id: "carreg-mat-base",
		name: "Carregamento de material para base",
		kind: "servico"
	},
	{
		id: "carreg-bica-subbase",
		name: "Carregamento de bica para sub-base",
		kind: "servico"
	},
	{
		id: "carreg-bica-base",
		name: "Carregamento de bica para base",
		kind: "servico"
	},
	{
		id: "carreg-bica-caixa",
		name: "Carregamento de bica para caixa ralo",
		kind: "servico"
	},
	{
		id: "carreg-reg-subleito",
		name: "Carregamento de material de regularização de subleito",
		kind: "servico"
	},
	{
		id: "carreg-borrachudo",
		name: "Carregamento de material borrachudo",
		kind: "servico"
	},
	{
		id: "transp-metalon",
		name: "Transporte de metalon",
		kind: "servico"
	},
	{
		id: "atendendo-outra-obra",
		name: "Atendendo outra obra",
		kind: "deslocamento"
	},
	{
		id: "umid-subbase",
		name: "Umidificação de sub-base",
		kind: "servico"
	},
	{
		id: "umid-base",
		name: "Umidificação de base",
		kind: "servico"
	},
	{
		id: "abast-frente",
		name: "Abastecimento da frente de serviço",
		kind: "servico"
	},
	{
		id: "molhar-pedreira",
		name: "Molhar acessos da pedreira",
		kind: "servico"
	},
	{
		id: "abast-agua",
		name: "Abastecer caminhão com água",
		kind: "deslocamento"
	},
	{
		id: "prevencao-poeira",
		name: "Prevenção de poeira",
		kind: "servico"
	},
	{
		id: "transp-colab-ida",
		name: "Transporte de colaboradores Itaguaí → São Joaquim",
		kind: "servico"
	},
	{
		id: "transp-colab-volta",
		name: "Transporte de colaboradores São Joaquim → Itaguaí",
		kind: "servico"
	},
	{
		id: "transp-colab-marambaia",
		name: "Transporte de colaboradores Marambaia",
		kind: "servico"
	},
	{
		id: "recolhe-campo",
		name: "Recolher colaboradores no campo",
		kind: "servico"
	},
	{
		id: "recolhe-almoco",
		name: "Recolher colaboradores para almoço",
		kind: "servico"
	},
	{
		id: "transp-frente-colab",
		name: "Transporte de colaboradores para frente de serviço",
		kind: "servico"
	},
	{
		id: "transp-exame",
		name: "Transporte para exame médico",
		kind: "servico"
	},
	{
		id: "estacionada",
		name: "Canteiro — estacionada",
		kind: "status"
	},
	{
		id: "comp-subleito",
		name: "Compactação de subleito",
		kind: "servico"
	},
	{
		id: "comp-subbase",
		name: "Compactação de sub-base",
		kind: "servico"
	},
	{
		id: "comp-base",
		name: "Compactação de base",
		kind: "servico"
	},
	{
		id: "comp-solo",
		name: "Compactação de solo",
		kind: "servico"
	},
	{
		id: "comp-reparo-erosao",
		name: "Compactação após reparo de erosão",
		kind: "servico"
	},
	{
		id: "comp-apos-pv",
		name: "Compactação após execução de PV",
		kind: "servico"
	},
	{
		id: "foi-frente",
		name: "Foi para frente de serviço",
		kind: "deslocamento"
	},
	{
		id: "voltou-canteiro",
		name: "Voltou ao canteiro",
		kind: "deslocamento"
	},
	{
		id: "puxada-material",
		name: "Puxada de material",
		kind: "servico"
	},
	{
		id: "puxada-drenagem",
		name: "Puxada de material para drenagem",
		kind: "servico"
	},
	{
		id: "puxada-pulmao",
		name: "Puxada de material para pulmão da obra",
		kind: "servico"
	},
	{
		id: "transp-material",
		name: "Transporte de material",
		kind: "servico"
	},
	{
		id: "chegou-canteiro",
		name: "Chegou ao canteiro",
		kind: "deslocamento"
	},
	{
		id: "saiu-manutencao",
		name: "Saiu da manutenção",
		kind: "deslocamento"
	},
	{
		id: "a-disposicao",
		name: "À disposição",
		kind: "status",
		code: "C4"
	},
	{
		id: "aguard-frente",
		name: "À disposição — aguardando frente",
		kind: "status",
		code: "C1"
	},
	{
		id: "aguard-material",
		name: "Aguardando materiais",
		kind: "status",
		code: "C2"
	},
	{
		id: "em-manutencao",
		name: "Em manutenção",
		kind: "status",
		code: "B4"
	},
	{
		id: "problema-mec",
		name: "Problema mecânico",
		kind: "status",
		code: "B3"
	},
	{
		id: "pneu-furado",
		name: "Pneu furado",
		kind: "status",
		code: "B1"
	},
	{
		id: "tempo-chuvoso",
		name: "Tempo chuvoso",
		kind: "status",
		code: "A1"
	},
	{
		id: "solo-saturado",
		name: "Solo saturado — impraticável",
		kind: "status",
		code: "A1"
	},
	{
		id: "motorista-ausente",
		name: "Motorista / operador ausente",
		kind: "status",
		code: "C6"
	},
	{
		id: "falta-operador",
		name: "Falta de operador",
		kind: "status",
		code: "C6"
	}
];
var RETRO = [
	"transp-equip-frente",
	"preparo-calcada",
	"exec-caixa-ralo",
	"exec-ramal",
	"icamento-caixa-ralo",
	"icamento-ramal",
	"alteamento-tampa",
	"espalh-bica-base",
	"espalh-bica-subbase",
	"espalh-mat-subbase",
	"carreg-cam-bica",
	"carreg-cam-mat",
	"descarga-aneis",
	"descarga-tubos",
	"demolicao-calcada",
	"demolicao-emborcadura",
	"limpeza-material",
	"org-canteiro",
	"org-desague",
	"escavacao",
	"abertura-vala",
	"reaterro",
	"reaterro-escada",
	"reparo-erosao",
	"reparo-esgoto",
	"reparo-caixa-ralo",
	"troca-solo-borrachudo",
	"exec-drenagem",
	"regularizacao-via",
	"nivelamento",
	"chegou-canteiro",
	"saiu-manutencao",
	"a-disposicao",
	"aguard-frente",
	"em-manutencao",
	"problema-mec",
	"tempo-chuvoso",
	"solo-saturado",
	"falta-operador"
];
var BASCULANTE = [
	"carreg-mat-subbase",
	"carreg-mat-base",
	"carreg-bica-subbase",
	"carreg-bica-base",
	"carreg-bica-caixa",
	"carreg-reg-subleito",
	"carreg-borrachudo",
	"transp-metalon",
	"atendendo-outra-obra",
	"chegou-canteiro",
	"saiu-manutencao",
	"a-disposicao",
	"aguard-frente",
	"em-manutencao",
	"problema-mec",
	"pneu-furado",
	"tempo-chuvoso",
	"solo-saturado",
	"motorista-ausente"
];
var PIPA = [
	"umid-subbase",
	"umid-base",
	"abast-frente",
	"molhar-pedreira",
	"abast-agua",
	"prevencao-poeira",
	"atendendo-outra-obra",
	"chegou-canteiro",
	"saiu-manutencao",
	"a-disposicao",
	"aguard-frente",
	"em-manutencao",
	"problema-mec",
	"tempo-chuvoso",
	"motorista-ausente"
];
var VAN = [
	"transp-colab-ida",
	"transp-colab-volta",
	"transp-colab-marambaia",
	"recolhe-campo",
	"recolhe-almoco",
	"transp-frente-colab",
	"transp-exame",
	"estacionada",
	"chegou-canteiro",
	"saiu-manutencao",
	"a-disposicao",
	"em-manutencao",
	"tempo-chuvoso",
	"motorista-ausente"
];
var ROLO = [
	"comp-subleito",
	"comp-subbase",
	"comp-base",
	"comp-solo",
	"comp-reparo-erosao",
	"comp-apos-pv",
	"foi-frente",
	"voltou-canteiro",
	"a-disposicao",
	"aguard-frente",
	"em-manutencao",
	"problema-mec",
	"tempo-chuvoso",
	"solo-saturado"
];
var TRUCK = [
	"puxada-material",
	"puxada-drenagem",
	"puxada-pulmao",
	"transp-material",
	"regularizacao-via",
	"carreg-mat-subbase",
	"carreg-bica-subbase",
	"chegou-canteiro",
	"a-disposicao",
	"aguard-frente",
	"em-manutencao",
	"pneu-furado",
	"tempo-chuvoso",
	"motorista-ausente"
];
var EQUIPMENT = [
	{
		id: "lok-453",
		code: "LOK 453",
		name: "Retroescavadeira LOK 453",
		kind: "retro",
		activityIds: RETRO,
		active: true
	},
	{
		id: "lok-457",
		code: "LOK 457",
		name: "Retroescavadeira LOK 457",
		kind: "retro",
		activityIds: RETRO,
		active: true
	},
	{
		id: "lye-200",
		code: "LYE 200",
		name: "Retroescavadeira LYE 200",
		kind: "retro",
		activityIds: RETRO,
		active: true
	},
	{
		id: "loc-204",
		code: "LOC 204",
		name: "Retroescavadeira CASE 580N LOC 204",
		kind: "retro",
		activityIds: RETRO,
		active: true
	},
	{
		id: "loc-304",
		code: "LOC 304",
		name: "Retroescavadeira John Deere LOC 304",
		kind: "retro",
		activityIds: RETRO,
		active: true
	},
	{
		id: "loc-073",
		code: "LOC 073",
		name: "Rolo Compactador LOC 073",
		kind: "rolo",
		activityIds: ROLO,
		active: true
	},
	{
		id: "lyc-154",
		code: "LYC 154",
		name: "Caminhão Traçado LYC 154",
		kind: "basculante",
		activityIds: BASCULANTE,
		active: true
	},
	{
		id: "lyc-317",
		code: "LYC 317",
		name: "Caminhão Traçado LYC 317",
		kind: "basculante",
		activityIds: BASCULANTE,
		active: true
	},
	{
		id: "lyc-025",
		code: "LYC 025",
		name: "Caminhão Pipa LYC 025",
		kind: "pipa",
		activityIds: PIPA,
		active: true
	},
	{
		id: "lyc-303",
		code: "LYC 303",
		name: "Van Sprinter LYC 303",
		kind: "van",
		activityIds: VAN,
		active: true
	},
	{
		id: "lqo0b03",
		code: "LQO0B03",
		name: "Caminhão Truck LQO0B03",
		kind: "truck",
		activityIds: TRUCK,
		active: true
	},
	{
		id: "loc-232",
		code: "LOC 232",
		name: "Caminhão Cachorreira LLT2H91 LOC 232",
		kind: "truck",
		activityIds: TRUCK,
		active: true
	},
	{
		id: "loc-799",
		code: "LOC 799",
		name: "Caminhão Toco LOC 799",
		kind: "truck",
		plate: "LAR5861",
		activityIds: TRUCK,
		active: true
	}
];
var WORKS = [
	{
		id: "l449",
		code: "L449",
		name: "São Joaquim",
		active: true
	},
	{
		id: "l442",
		code: "L442",
		name: "Miguel Pereira",
		active: true
	},
	{
		id: "l389",
		code: "L389",
		name: "Amaro Cavalcante",
		active: true
	},
	{
		id: "l388",
		code: "L388",
		name: "São Domingos Sávio",
		active: true
	},
	{
		id: "l513",
		code: "L513",
		name: "Pedreira",
		active: true
	}
];
var STREETS = [
	{
		id: "visconde",
		name: "Rua Visconde de Itaboraí",
		workId: "l449",
		active: true
	},
	{
		id: "augusto",
		name: "Rua Pref. Augusto de Andrade",
		workId: "l449",
		active: true
	},
	{
		id: "alberto",
		name: "Rua Alberto Torres",
		workId: "l449",
		active: true
	},
	{
		id: "jose-leandro",
		name: "Rua José Leandro",
		workId: "l449",
		active: true
	},
	{
		id: "joao-caetano",
		name: "Rua João Caetano",
		workId: "l449",
		active: true
	},
	{
		id: "margaridas",
		name: "Rua das Margaridas",
		workId: "l388",
		active: true
	},
	{
		id: "hermes",
		name: "Travessa Hermes",
		workId: "l388",
		active: true
	},
	{
		id: "sao-domingos",
		name: "Rua São Domingos Sávio",
		workId: "l388",
		active: true
	},
	{
		id: "uva",
		name: "Rua Uva",
		workId: "l388",
		active: true
	},
	{
		id: "jerusalem",
		name: "Rua Jerusalém",
		workId: "l388",
		active: true
	}
];
var KIND_LABEL = {
	retro: "Retroescavadeira",
	rolo: "Rolo compactador",
	basculante: "Caminhão traçado",
	pipa: "Caminhão pipa",
	van: "Van / transporte",
	truck: "Caminhão"
};
var QUANTITY_LABEL = {
	basculante: "Viagens",
	truck: "Viagens",
	pipa: "Cargas de água",
	retro: "Viagens carregadas"
};
var PV_PREFIXES = [
	"PVD",
	"PVC",
	"PVE",
	"PV",
	"PVA"
];
var NOTE_CHIPS = [
	"Tempo chuvoso",
	"Solo saturado",
	"Aguardando frente de serviço",
	"Motorista ausente",
	"Saiu da manutenção",
	"Chegou ao canteiro"
];
function buildDescription(input) {
	const eq = input.equipmentName.trim();
	const act = input.activityName.trim().toLowerCase();
	const rua = input.streetName.trim();
	const estaca = formatEstaca(input.estaca);
	const pv = input.pv.trim();
	if (!eq || !act) return "";
	const doing = `${eq} realizando ${act}`;
	if (!rua && !estaca && !pv) return `${doing}.`;
	if (!rua) {
		const bits = [estaca && `na Estaca ${estaca.replace(/^E\s*/i, "")}`, pv && `no ${pv}`].filter(Boolean);
		return `${doing}${bits.length ? `, ${bits.join(" e ")}` : ""}.`;
	}
	if (estaca && pv) return `${doing} na ${rua}, entre a Estaca ${estaca.replace(/^E\s*/i, "")} e o ${pv}.`;
	if (estaca) return `${doing} na ${rua}, na Estaca ${estaca.replace(/^E\s*/i, "")}.`;
	if (pv) return `${doing} na ${rua}, no ${pv}.`;
	return `${doing} na ${rua}.`;
}
function mergeById(seed, saved) {
	const map = new Map((saved ?? []).map((x) => [x.id, x]));
	for (const item of seed) if (!map.has(item.id)) map.set(item.id, item);
	return [...map.values()];
}
function snapshots(draft, get) {
	const s = get();
	const work = s.works.find((w) => w.id === draft.workId);
	const street = s.streets.find((st) => st.id === draft.streetId);
	const eq = s.equipment.find((e) => e.id === draft.equipmentId);
	const act = s.activities.find((a) => a.id === draft.activityId);
	const qty = draft.quantity.trim() === "" ? null : Number(draft.quantity);
	const description = buildDescription({
		equipmentName: eq?.name ?? "",
		activityName: act?.name ?? "",
		streetName: street?.name ?? "",
		estaca: draft.estaca,
		pv: draft.pv
	});
	return {
		workId: draft.workId,
		workName: work ? `${work.code} ${work.name}` : "",
		streetId: draft.streetId,
		streetName: street?.name ?? "",
		equipmentId: draft.equipmentId,
		equipmentName: eq?.name ?? "",
		equipmentKind: eq?.kind ?? "retro",
		activityId: draft.activityId,
		activityName: act?.name ?? "",
		estaca: draft.estaca.trim(),
		pv: draft.pv.trim(),
		quantity: Number.isFinite(qty) ? qty : null,
		quantityLabel: "",
		notes: draft.notes.trim(),
		description
	};
}
var useStore = create()(persist((set, get) => ({
	hydrated: false,
	works: WORKS,
	streets: STREETS,
	equipment: EQUIPMENT,
	activities: ACTIVITIES,
	apontamentos: [],
	last: {
		workId: "l449",
		streetId: "visconde",
		equipmentId: "lok-453",
		activityId: "exec-caixa-ralo"
	},
	setHydrated: () => set({ hydrated: true }),
	setLast: (patch) => set({ last: {
		...get().last,
		...patch
	} }),
	addWork: (w) => {
		const id = uid();
		set({ works: [...get().works, {
			...w,
			id,
			active: true
		}] });
		return id;
	},
	addStreet: (s) => {
		const id = uid();
		set({ streets: [...get().streets, {
			...s,
			id,
			active: true
		}] });
		return id;
	},
	addEquipment: (e) => {
		const id = uid();
		set({ equipment: [...get().equipment, {
			...e,
			id,
			active: true
		}] });
		return id;
	},
	addActivity: (a, equipmentId) => {
		const id = uid();
		const activities = [...get().activities, {
			...a,
			id
		}];
		let equipment = get().equipment;
		if (equipmentId) equipment = equipment.map((eq) => eq.id === equipmentId ? {
			...eq,
			activityIds: [...eq.activityIds, id]
		} : eq);
		set({
			activities,
			equipment
		});
		return id;
	},
	updateEquipment: (id, patch) => set({ equipment: get().equipment.map((e) => e.id === id ? {
		...e,
		...patch
	} : e) }),
	updateStreet: (id, patch) => set({ streets: get().streets.map((s) => s.id === id ? {
		...s,
		...patch
	} : s) }),
	updateActivity: (id, patch) => set({ activities: get().activities.map((a) => a.id === id ? {
		...a,
		...patch
	} : a) }),
	toggleEquipment: (id) => set({ equipment: get().equipment.map((e) => e.id === id ? {
		...e,
		active: !e.active
	} : e) }),
	toggleStreet: (id) => set({ streets: get().streets.map((s) => s.id === id ? {
		...s,
		active: !s.active
	} : s) }),
	saveApontamento: (draft, editingId) => {
		const now = (/* @__PURE__ */ new Date()).toISOString();
		const snap = snapshots(draft, get);
		const end = draft.ended && draft.end ? draft.end : null;
		if (!editingId) {
			const sameOpen = get().apontamentos.find((a) => a.equipmentId === draft.equipmentId && a.end === null && a.date === draft.date);
			if (sameOpen) get().closeApontamento(sameOpen.id, draft.start);
		}
		if (editingId) {
			const updated = {
				...get().apontamentos.find((a) => a.id === editingId),
				...snap,
				date: draft.date,
				start: draft.start,
				end,
				updatedAt: now
			};
			set({
				apontamentos: get().apontamentos.map((a) => a.id === editingId ? updated : a),
				last: {
					workId: draft.workId,
					streetId: draft.streetId,
					equipmentId: draft.equipmentId,
					activityId: draft.activityId
				}
			});
			return updated;
		}
		const created = {
			id: uid(),
			date: draft.date,
			start: draft.start,
			end,
			...snap,
			createdAt: now,
			updatedAt: now
		};
		set({
			apontamentos: [...get().apontamentos, created],
			last: {
				workId: draft.workId,
				streetId: draft.streetId,
				equipmentId: draft.equipmentId,
				activityId: draft.activityId
			}
		});
		return created;
	},
	closeApontamento: (id, end) => {
		const t = end ?? nowHHMM();
		set({ apontamentos: get().apontamentos.map((a) => a.id === id ? {
			...a,
			end: t,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		} : a) });
	},
	deleteApontamento: (id) => set({ apontamentos: get().apontamentos.filter((a) => a.id !== id) }),
	updateApontamento: (id, patch) => set({ apontamentos: get().apontamentos.map((a) => a.id === id ? {
		...a,
		...patch,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	} : a) })
}), {
	name: "apontador-v1",
	merge: (persisted, current) => {
		const p = persisted ?? {};
		return {
			...current,
			...p,
			works: mergeById(WORKS, p.works),
			streets: mergeById(STREETS, p.streets),
			equipment: mergeById(EQUIPMENT, p.equipment),
			activities: mergeById(ACTIVITIES, p.activities),
			apontamentos: p.apontamentos ?? current.apontamentos,
			last: {
				...current.last,
				...p.last
			}
		};
	},
	onRehydrateStorage: () => (state) => {
		state?.setHydrated();
	},
	partialize: (s) => ({
		works: s.works,
		streets: s.streets,
		equipment: s.equipment,
		activities: s.activities,
		apontamentos: s.apontamentos,
		last: s.last
	})
}));
function emptyDraft(last) {
	return {
		date: todayISO(),
		start: nowHHMM(),
		end: nowHHMM(),
		ended: false,
		workId: last.workId,
		streetId: last.streetId,
		equipmentId: last.equipmentId,
		activityId: last.activityId,
		estaca: "",
		pv: "",
		quantity: "",
		notes: ""
	};
}
function draftFromApontamento(a) {
	return {
		date: a.date,
		start: a.start,
		end: a.end ?? nowHHMM(),
		ended: Boolean(a.end),
		workId: a.workId,
		streetId: a.streetId,
		equipmentId: a.equipmentId,
		activityId: a.activityId,
		estaca: a.estaca,
		pv: a.pv,
		quantity: a.quantity == null ? "" : String(a.quantity),
		notes: a.notes
	};
}
//#endregion
export { nowHHMM as _, Label as a, QUANTITY_LABEL as c, cn as d, draftFromApontamento as f, minutesBetween as g, formatDuration as h, KIND_LABEL as i, Textarea as l, formatDateBR as m, Button as n, NOTE_CHIPS as o, emptyDraft as p, Input as r, PV_PREFIXES as s, AppShell as t, buildDescription as u, todayISO as v, useStore as y };
