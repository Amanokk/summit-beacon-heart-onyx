import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as useStore } from "./store-DX0a_orN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hydrate-B6lDvGyw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function useHydration() {
	const hydrated = useStore((s) => s.hydrated);
	(0, import_react.useEffect)(() => {
		const finish = () => useStore.getState().setHydrated();
		const unsub = useStore.persist.onFinishHydration(finish);
		if (useStore.persist.hasHydrated()) finish();
		const t = window.setTimeout(finish, 400);
		return () => {
			unsub();
			window.clearTimeout(t);
		};
	}, []);
	return hydrated;
}
//#endregion
export { useHydration as t };
