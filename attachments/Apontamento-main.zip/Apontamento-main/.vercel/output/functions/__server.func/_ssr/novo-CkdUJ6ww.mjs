import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as require_jsx_runtime, b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as ArrowLeft } from "../_libs/lucide-react.mjs";
import { _ as nowHHMM, a as Label, c as QUANTITY_LABEL, f as draftFromApontamento, i as KIND_LABEL, l as Textarea, n as Button, o as NOTE_CHIPS, p as emptyDraft, r as Input, s as PV_PREFIXES, t as AppShell, u as buildDescription, y as useStore } from "./store-DX0a_orN.mjs";
import { n as ChoiceList, t as ChipRow } from "./choice-DIu49KzF.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Route$1 } from "./router-BqKkIl53.mjs";
import { t as useHydration } from "./hydrate-B6lDvGyw.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/novo-CkdUJ6ww.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ApontamentoForm({ draft, onChange, onSubmit, submitLabel = "Salvar" }) {
	const { streets, equipment, activities, works } = useStore();
	const [qEq, setQEq] = (0, import_react.useState)("");
	const [qSt, setQSt] = (0, import_react.useState)("");
	const [qAct, setQAct] = (0, import_react.useState)("");
	const [customAct, setCustomAct] = (0, import_react.useState)("");
	const addActivity = useStore((s) => s.addActivity);
	const eq = equipment.find((e) => e.id === draft.equipmentId);
	const act = activities.find((a) => a.id === draft.activityId);
	const street = streets.find((s) => s.id === draft.streetId);
	const work = works.find((w) => w.id === draft.workId);
	const streetOpts = (0, import_react.useMemo)(() => {
		const list = streets.filter((s) => s.active && (!draft.workId || s.workId === draft.workId));
		const q = qSt.trim().toLowerCase();
		return (q ? list.filter((s) => s.name.toLowerCase().includes(q)) : list).map((s) => ({
			id: s.id,
			label: s.name
		}));
	}, [
		streets,
		draft.workId,
		qSt
	]);
	const eqOpts = (0, import_react.useMemo)(() => {
		const list = equipment.filter((e) => e.active);
		const q = qEq.trim().toLowerCase();
		return (q ? list.filter((e) => `${e.name} ${e.code}`.toLowerCase().includes(q)) : list).map((e) => ({
			id: e.id,
			label: e.name,
			hint: KIND_LABEL[e.kind]
		}));
	}, [equipment, qEq]);
	const actOpts = (0, import_react.useMemo)(() => {
		const ids = new Set(eq?.activityIds ?? []);
		const list = activities.filter((a) => ids.has(a.id));
		const servico = list.filter((a) => a.kind === "servico");
		const other = list.filter((a) => a.kind !== "servico");
		const ordered = [...servico, ...other];
		const q = qAct.trim().toLowerCase();
		return (q ? ordered.filter((a) => a.name.toLowerCase().includes(q)) : ordered).map((a) => ({
			id: a.id,
			label: a.name,
			hint: a.kind === "status" ? "Status" : void 0
		}));
	}, [
		activities,
		eq,
		qAct
	]);
	const preview = buildDescription({
		equipmentName: eq?.name ?? "",
		activityName: act?.name ?? "",
		streetName: street?.name ?? "",
		estaca: draft.estaca,
		pv: draft.pv
	});
	const qtyLabel = eq ? QUANTITY_LABEL[eq.kind] : void 0;
	const canSave = Boolean(draft.equipmentId && draft.activityId && draft.streetId && draft.start);
	function set(patch) {
		onChange({
			...draft,
			...patch
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6 pb-28",
		children: [
			preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
				className: "rounded-xl border border-border bg-surface p-4 text-[15px] leading-snug text-fg shadow-card",
				children: preview
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Obra" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceList, {
				options: works.filter((w) => w.active).map((w) => ({
					id: w.id,
					label: `${w.code} · ${w.name}`
				})),
				value: draft.workId,
				onChange: (id) => {
					set({
						workId: id,
						streetId: streets.find((s) => s.active && s.workId === id)?.id ?? draft.streetId
					});
				}
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "1. Rua" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: qSt,
					onChange: (e) => setQSt(e.target.value),
					placeholder: "Filtrar rua…",
					className: "mb-2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceList, {
					options: streetOpts,
					value: draft.streetId,
					onChange: (id) => set({ streetId: id })
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "2. Máquina / caminhão" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: qEq,
					onChange: (e) => setQEq(e.target.value),
					placeholder: "Filtrar equipamento…",
					className: "mb-2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceList, {
					options: eqOpts,
					value: draft.equipmentId,
					onChange: (id) => {
						const next = equipment.find((e) => e.id === id);
						const keep = next?.activityIds.includes(draft.activityId);
						set({
							equipmentId: id,
							activityId: keep ? draft.activityId : next?.activityIds[0] ?? ""
						});
					}
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "3. Atividade desta máquina" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: qAct,
					onChange: (e) => setQAct(e.target.value),
					placeholder: "Filtrar atividade…",
					className: "mb-2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceList, {
					options: actOpts,
					value: draft.activityId,
					onChange: (id) => set({ activityId: id })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: customAct,
						onChange: (e) => setCustomAct(e.target.value),
						placeholder: "Nova atividade para esta máquina"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						disabled: !customAct.trim() || !eq,
						onClick: () => {
							if (!eq) return;
							set({ activityId: addActivity({
								name: customAct.trim(),
								kind: "servico"
							}, eq.id) });
							setCustomAct("");
						},
						children: "Incluir"
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "4. Estaca" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: draft.estaca,
						onChange: (e) => set({ estaca: e.target.value }),
						placeholder: "15+20 ou 1015",
						inputMode: "text"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex gap-2",
						children: ["+20", "+50"].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							size: "sm",
							variant: "secondary",
							onClick: () => bumpEstaca(draft.estaca, Number(s), set),
							children: s
						}, s))
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "5. PV" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: draft.pv,
						onChange: (e) => set({ pv: e.target.value.toUpperCase() }),
						placeholder: "PVD-08"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipRow, {
							options: [...PV_PREFIXES],
							onChange: (p) => {
								const num = draft.pv.replace(/^[A-Z]+-?/, "");
								set({ pv: num ? `${p}-${num}` : `${p}-` });
							}
						})
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "6. Horário" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1 text-xs text-muted",
							children: "Início"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "time",
							value: draft.start,
							onChange: (e) => set({ start: e.target.value })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							size: "sm",
							variant: "ghost",
							className: "mt-1 px-0",
							onClick: () => set({ start: nowHHMM() }),
							children: "Agora"
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-1 text-xs text-muted",
							children: "Término"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "time",
							value: draft.end,
							disabled: !draft.ended,
							onChange: (e) => set({ end: e.target.value })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							size: "sm",
							variant: "ghost",
							className: "mt-1 px-0",
							onClick: () => set({
								ended: !draft.ended,
								end: nowHHMM()
							}),
							children: draft.ended ? "Deixar em andamento" : "Já encerrou"
						})
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					className: "mt-2",
					value: draft.date,
					onChange: (e) => set({ date: e.target.value })
				})
			] }),
			qtyLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: qtyLabel }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						onClick: () => stepQty(draft.quantity, -1, set),
						children: "−"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						inputMode: "numeric",
						value: draft.quantity,
						onChange: (e) => set({ quantity: e.target.value.replace(/[^\d]/g, "") }),
						className: "text-center tabular-nums"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						onClick: () => stepQty(draft.quantity, 1, set),
						children: "+"
					})
				]
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "7. Observação" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChipRow, {
					options: NOTE_CHIPS,
					onChange: (n) => set({ notes: draft.notes ? `${draft.notes} / ${n}` : n })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					className: "mt-2",
					value: draft.notes,
					onChange: (e) => set({ notes: e.target.value }),
					placeholder: "Opcional"
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted",
				children: [work ? `${work.code} ${work.name}` : "Sem obra", " · toque em salvar para registrar no celular"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "no-print fixed inset-x-0 bottom-0 z-20 mx-auto max-w-lg border-t border-border bg-surface/95 p-3 pb-[max(12px,env(safe-area-inset-bottom))] backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "w-full",
					size: "lg",
					disabled: !canSave,
					onClick: onSubmit,
					children: submitLabel
				})
			})
		]
	});
}
function bumpEstaca(current, delta, set) {
	const plus = current.match(/^(\d+)\+(\d+)$/);
	if (plus) {
		let km = Number(plus[1]);
		let m = Number(plus[2]) + delta;
		while (m >= 100) {
			km += 1;
			m -= 100;
		}
		while (m < 0) {
			km -= 1;
			m += 100;
		}
		if (km < 0) return;
		set({ estaca: `${km}+${String(m).padStart(2, "0")}` });
		return;
	}
	const n = current.replace(/\D/g, "");
	if (!n) {
		set({ estaca: String(Math.max(0, delta)) });
		return;
	}
	set({ estaca: String(Math.max(0, Number(n) + delta)) });
}
function stepQty(current, d, set) {
	const n = Math.max(0, (Number(current) || 0) + d);
	set({ quantity: n ? String(n) : "" });
}
function Novo() {
	const { edit } = Route$1.useSearch();
	const navigate = useNavigate();
	const store = useStore();
	useHydration();
	const existing = edit ? store.apontamentos.find((a) => a.id === edit) : void 0;
	const [draft, setDraft] = (0, import_react.useState)(() => existing ? draftFromApontamento(existing) : emptyDraft(store.last));
	(0, import_react.useEffect)(() => {
		if (existing) setDraft(draftFromApontamento(existing));
	}, [existing]);
	function save() {
		store.saveApontamento(draft, existing?.id);
		toast.success(existing ? "Apontamento atualizado" : "Apontamento salvo");
		navigate({ to: "/" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		hideNav: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center gap-3 px-3 pb-2 pt-[max(12px,env(safe-area-inset-top))]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => void navigate({ to: "/" }),
				className: "flex size-12 items-center justify-center rounded-md text-fg",
				"aria-label": "Voltar",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-xl font-semibold",
				children: existing ? "Editar apontamento" : "Novo apontamento"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: "Poucos toques. A descrição monta sozinha."
			})] })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "px-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApontamentoForm, {
				draft,
				onChange: setDraft,
				onSubmit: save,
				submitLabel: existing ? "Salvar alteração" : "Salvar"
			})
		})]
	});
}
//#endregion
export { Novo as component };
