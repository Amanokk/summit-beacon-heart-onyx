import { create } from "zustand";
import { persist } from "zustand/middleware";
import { ACTIVITIES, EQUIPMENT, STREETS, WORKS } from "./catalog";
import { buildDescription } from "./description";
import type { Activity, Apontamento, Draft, Equipment, Street, Work } from "./types";
import { todayISO, nowHHMM, uid } from "./utils";

export type LastUsed = {
  workId: string;
  streetId: string;
  equipmentId: string;
  activityId: string;
};

type State = {
  hydrated: boolean;
  works: Work[];
  streets: Street[];
  equipment: Equipment[];
  activities: Activity[];
  apontamentos: Apontamento[];
  last: LastUsed;
  setHydrated: () => void;
  setLast: (patch: Partial<LastUsed>) => void;
  addWork: (w: Omit<Work, "id" | "active">) => string;
  addStreet: (s: Omit<Street, "id" | "active">) => string;
  addEquipment: (e: Omit<Equipment, "id" | "active">) => string;
  addActivity: (a: Omit<Activity, "id">, equipmentId?: string) => string;
  updateEquipment: (id: string, patch: Partial<Equipment>) => void;
  updateStreet: (id: string, patch: Partial<Street>) => void;
  updateActivity: (id: string, patch: Partial<Activity>) => void;
  toggleEquipment: (id: string) => void;
  toggleStreet: (id: string) => void;
  saveApontamento: (draft: Draft, editingId?: string) => Apontamento;
  closeApontamento: (id: string, end?: string) => void;
  deleteApontamento: (id: string) => void;
  updateApontamento: (id: string, patch: Partial<Apontamento>) => void;
};

function mergeById<T extends { id: string }>(seed: T[], saved: T[] | undefined): T[] {
  const map = new Map((saved ?? []).map((x) => [x.id, x]));
  for (const item of seed) {
    if (!map.has(item.id)) map.set(item.id, item);
  }
  return [...map.values()];
}

function snapshots(draft: Draft, get: () => State) {
  const s = get();
  const work = s.works.find((w) => w.id === draft.workId);
  const street = s.streets.find((st) => st.id === draft.streetId);
  const eq = s.equipment.find((e) => e.id === draft.equipmentId);
  const act = s.activities.find((a) => a.id === draft.activityId);
  const qty = draft.quantity.trim() === "" ? null : Number(draft.quantity);
  const description = buildDescription({
    equipmentName: eq?.name ?? "",
    activityName: act?.name ?? "",
    streetName: street?.name ?? "",
    estaca: draft.estaca,
    pv: draft.pv,
  });
  return {
    workId: draft.workId,
    workName: work ? `${work.code} ${work.name}` : "",
    streetId: draft.streetId,
    streetName: street?.name ?? "",
    equipmentId: draft.equipmentId,
    equipmentName: eq?.name ?? "",
    equipmentKind: eq?.kind ?? ("retro" as const),
    activityId: draft.activityId,
    activityName: act?.name ?? "",
    estaca: draft.estaca.trim(),
    pv: draft.pv.trim(),
    quantity: Number.isFinite(qty) ? qty : null,
    quantityLabel: "",
    notes: draft.notes.trim(),
    description,
  };
}

export const useStore = create<State>()(
  persist(
    (set, get) => ({
      hydrated: false,
      works: WORKS,
      streets: STREETS,
      equipment: EQUIPMENT,
      activities: ACTIVITIES,
      apontamentos: [],
      last: {
        workId: "l449",
        streetId: "visconde",
        equipmentId: "lok-453",
        activityId: "exec-caixa-ralo",
      },
      setHydrated: () => set({ hydrated: true }),
      setLast: (patch) => set({ last: { ...get().last, ...patch } }),
      addWork: (w) => {
        const id = uid();
        set({ works: [...get().works, { ...w, id, active: true }] });
        return id;
      },
      addStreet: (s) => {
        const id = uid();
        set({ streets: [...get().streets, { ...s, id, active: true }] });
        return id;
      },
      addEquipment: (e) => {
        const id = uid();
        set({ equipment: [...get().equipment, { ...e, id, active: true }] });
        return id;
      },
      addActivity: (a, equipmentId) => {
        const id = uid();
        const activities = [...get().activities, { ...a, id }];
        let equipment = get().equipment;
        if (equipmentId) {
          equipment = equipment.map((eq) =>
            eq.id === equipmentId ? { ...eq, activityIds: [...eq.activityIds, id] } : eq,
          );
        }
        set({ activities, equipment });
        return id;
      },
      updateEquipment: (id, patch) =>
        set({
          equipment: get().equipment.map((e) => (e.id === id ? { ...e, ...patch } : e)),
        }),
      updateStreet: (id, patch) =>
        set({
          streets: get().streets.map((s) => (s.id === id ? { ...s, ...patch } : s)),
        }),
      updateActivity: (id, patch) =>
        set({
          activities: get().activities.map((a) => (a.id === id ? { ...a, ...patch } : a)),
        }),
      toggleEquipment: (id) =>
        set({
          equipment: get().equipment.map((e) => (e.id === id ? { ...e, active: !e.active } : e)),
        }),
      toggleStreet: (id) =>
        set({
          streets: get().streets.map((s) => (s.id === id ? { ...s, active: !s.active } : s)),
        }),
      saveApontamento: (draft, editingId) => {
        const now = new Date().toISOString();
        const snap = snapshots(draft, get);
        const end = draft.ended && draft.end ? draft.end : null;

        if (!editingId) {
          const sameOpen = get().apontamentos.find(
            (a) => a.equipmentId === draft.equipmentId && a.end === null && a.date === draft.date,
          );
          if (sameOpen) get().closeApontamento(sameOpen.id, draft.start);
        }

        if (editingId) {
          const prev = get().apontamentos.find((a) => a.id === editingId);
          const updated: Apontamento = {
            ...(prev as Apontamento),
            ...snap,
            date: draft.date,
            start: draft.start,
            end,
            updatedAt: now,
          };
          set({
            apontamentos: get().apontamentos.map((a) => (a.id === editingId ? updated : a)),
            last: {
              workId: draft.workId,
              streetId: draft.streetId,
              equipmentId: draft.equipmentId,
              activityId: draft.activityId,
            },
          });
          return updated;
        }

        const created: Apontamento = {
          id: uid(),
          date: draft.date,
          start: draft.start,
          end,
          ...snap,
          createdAt: now,
          updatedAt: now,
        };
        set({
          apontamentos: [...get().apontamentos, created],
          last: {
            workId: draft.workId,
            streetId: draft.streetId,
            equipmentId: draft.equipmentId,
            activityId: draft.activityId,
          },
        });
        return created;
      },
      closeApontamento: (id, end) => {
        const t = end ?? nowHHMM();
        set({
          apontamentos: get().apontamentos.map((a) =>
            a.id === id ? { ...a, end: t, updatedAt: new Date().toISOString() } : a,
          ),
        });
      },
      deleteApontamento: (id) =>
        set({ apontamentos: get().apontamentos.filter((a) => a.id !== id) }),
      updateApontamento: (id, patch) =>
        set({
          apontamentos: get().apontamentos.map((a) =>
            a.id === id ? { ...a, ...patch, updatedAt: new Date().toISOString() } : a,
          ),
        }),
    }),
    {
      name: "apontador-v1",
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<State>;
        return {
          ...current,
          ...p,
          works: mergeById(WORKS, p.works),
          streets: mergeById(STREETS, p.streets),
          equipment: mergeById(EQUIPMENT, p.equipment),
          activities: mergeById(ACTIVITIES, p.activities),
          apontamentos: p.apontamentos ?? current.apontamentos,
          last: { ...current.last, ...p.last },
        };
      },
      onRehydrateStorage: () => (state) => {
        state?.setHydrated();
      },
      partialize: (s) => ({
        works: s.works,
        streets: s.streets,
        equipment: s.equipment,
        activities: s.activities,
        apontamentos: s.apontamentos,
        last: s.last,
      }),
    },
  ),
);

export function emptyDraft(last: LastUsed): Draft {
  return {
    date: todayISO(),
    start: nowHHMM(),
    end: nowHHMM(),
    ended: false,
    workId: last.workId,
    streetId: last.streetId,
    equipmentId: last.equipmentId,
    activityId: last.activityId,
    estaca: "",
    pv: "",
    quantity: "",
    notes: "",
  };
}

export function draftFromApontamento(a: Apontamento): Draft {
  return {
    date: a.date,
    start: a.start,
    end: a.end ?? nowHHMM(),
    ended: Boolean(a.end),
    workId: a.workId,
    streetId: a.streetId,
    equipmentId: a.equipmentId,
    activityId: a.activityId,
    estaca: a.estaca,
    pv: a.pv,
    quantity: a.quantity == null ? "" : String(a.quantity),
    notes: a.notes,
  };
}
