import { useEffect } from "react";
import { useStore } from "./store";

export function useHydration(): boolean {
  const hydrated = useStore((s) => s.hydrated);
  useEffect(() => {
    const finish = () => useStore.getState().setHydrated();
    const unsub = useStore.persist.onFinishHydration(finish);
    if (useStore.persist.hasHydrated()) finish();
    const t = window.setTimeout(finish, 400);
    return () => {
      unsub();
      window.clearTimeout(t);
    };
  }, []);
  return hydrated;
}
