export type EquipmentKind =
  | "retro"
  | "rolo"
  | "basculante"
  | "pipa"
  | "van"
  | "truck";

export type ActivityKind = "servico" | "status" | "deslocamento";

export type Equipment = {
  id: string;
  code: string;
  name: string;
  kind: EquipmentKind;
  plate?: string;
  operator?: string;
  activityIds: string[];
  active: boolean;
};

export type Activity = {
  id: string;
  name: string;
  kind: ActivityKind;
  code?: string;
};

export type Street = {
  id: string;
  name: string;
  workId: string;
  active: boolean;
};

export type Work = {
  id: string;
  code: string;
  name: string;
  active: boolean;
};

export type Apontamento = {
  id: string;
  date: string;
  start: string;
  end: string | null;
  workId: string;
  workName: string;
  streetId: string;
  streetName: string;
  equipmentId: string;
  equipmentName: string;
  equipmentKind: EquipmentKind;
  activityId: string;
  activityName: string;
  estaca: string;
  pv: string;
  quantity: number | null;
  quantityLabel: string;
  notes: string;
  description: string;
  createdAt: string;
  updatedAt: string;
};

export type Draft = {
  date: string;
  start: string;
  end: string;
  ended: boolean;
  workId: string;
  streetId: string;
  equipmentId: string;
  activityId: string;
  estaca: string;
  pv: string;
  quantity: string;
  notes: string;
};
