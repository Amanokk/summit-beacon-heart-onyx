export function ScreenLoader() {
  return (
    <div className="flex min-h-dvh flex-col gap-3 bg-bg px-4 pt-16">
      <div className="h-8 w-40 rounded-md bg-surface-2" />
      <div className="h-16 rounded-xl bg-surface-2" />
      <div className="h-28 rounded-xl bg-surface-2" />
      <div className="h-24 rounded-xl bg-surface-2" />
    </div>
  );
}
