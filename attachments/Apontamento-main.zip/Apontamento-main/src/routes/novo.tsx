import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ApontamentoForm } from "@/components/apontamento-form";
import { AppShell } from "@/components/app-shell";
import { draftFromApontamento, emptyDraft, useStore } from "@/lib/store";
import { useHydration } from "@/lib/hydrate";
import type { Draft } from "@/lib/types";

export const Route = createFileRoute("/novo")({
  validateSearch: (raw: Record<string, unknown>): { edit?: string } =>
    typeof raw.edit === "string" && raw.edit ? { edit: raw.edit } : {},
  component: Novo,
});

function Novo() {
  const { edit } = Route.useSearch();
  const navigate = useNavigate();
  const store = useStore();
  useHydration();
  const existing = edit ? store.apontamentos.find((a) => a.id === edit) : undefined;
  const [draft, setDraft] = useState<Draft>(() =>
    existing ? draftFromApontamento(existing) : emptyDraft(store.last),
  );

  useEffect(() => {
    if (existing) setDraft(draftFromApontamento(existing));
  }, [existing]);

  function save() {
    store.saveApontamento(draft, existing?.id);
    toast.success(existing ? "Apontamento atualizado" : "Apontamento salvo");
    void navigate({ to: "/" });
  }

  return (
    <AppShell hideNav>
      <header className="flex items-center gap-3 px-3 pb-2 pt-[max(12px,env(safe-area-inset-top))]">
        <button
          type="button"
          onClick={() => void navigate({ to: "/" })}
          className="flex size-12 items-center justify-center rounded-md text-fg"
          aria-label="Voltar"
        >
          <ArrowLeft className="size-5" />
        </button>
        <div>
          <h1 className="font-display text-xl font-semibold">
            {existing ? "Editar apontamento" : "Novo apontamento"}
          </h1>
          <p className="text-xs text-muted">Poucos toques. A descrição monta sozinha.</p>
        </div>
      </header>
      <main className="px-4">
        <ApontamentoForm
          draft={draft}
          onChange={setDraft}
          onSubmit={save}
          submitLabel={existing ? "Salvar alteração" : "Salvar"}
        />
      </main>
    </AppShell>
  );
}
